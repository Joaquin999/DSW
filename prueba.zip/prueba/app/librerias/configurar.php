<?php
// Ruta de la aplicación
define ("RUTA_APP", dirname(dirname (__FILE__)));
define("RUTA_URL", "http://192.168.114.3/prueba/");
define("NOMBRE_SITIO", "Modelo Vista Elementos");
