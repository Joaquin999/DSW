<script>
        function MuestraDel(num,boton) {
            let p = document.getElementById("parrafoDel");
            let tabla = document.getElementById("actual");
            p.innerHTML = `¿Quieres borrar el registro con ${tabla.innerHTML} = ${boton.value} ?`;

            let inputDel = document.getElementById("vDel");
            inputDel.value = boton.value;

        }

        function MuestraAct(num) {
          let knekro = document.getElementsByTagName("tr");
          for(let i=0; i<knekro[num].childNodes.length-2;i++){
            let tmp = document.getElementById(`valorAct${i+1}`);
            tmp.value=knekro[num].childNodes[i].innerHTML;
          }
        }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" language="javascript" src="../public/js/bootstrap/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script> $(document).ready(function () {
        $("#example").DataTable();
    });
</script>
</body>
</html>
